package me.ataur.bdlaws.admin.audit;

import me.ataur.bdlaws.admin.model.Act;
import me.ataur.bdlaws.admin.model.ActHistory;
import org.springframework.beans.factory.annotation.Autowired;


import javax.persistence.*;
import javax.transaction.Transactional;

import static javax.transaction.Transactional.TxType.MANDATORY;

/**
 * @author Naresh Joshi
 */

public class ActEntityListener {


	@PostPersist
	public void prePersist(Act target) {
		perform(target, Action.INSERTED);
	}

	@PostUpdate
	public void preUpdate(Act target) {
		perform(target, Action.UPDATED);
	}

	@PreRemove
	public void preRemove(Act target) {
		perform(target, Action.DELETED);
	}

	@Transactional(MANDATORY)
	private void perform(Act target, Action action) {
		EntityManager entityManager = BeanUtil.getBean(EntityManager.class);
		entityManager.persist(new ActHistory(target, action));
		System.out.println("Output test *****************************************************Output test1");
	}

}