package me.ataur.bdlaws.admin.audit;

import me.ataur.bdlaws.admin.model.Volume;

import javax.persistence.EntityManager;
import javax.persistence.PrePersist;
import javax.persistence.PreRemove;
import javax.persistence.PreUpdate;
import javax.transaction.Transactional;

import static javax.transaction.Transactional.TxType.MANDATORY;

import me.ataur.bdlaws.admin.model.VolumeHistory;

/**
 * @author Naresh Joshi
 */

public class VolumeEntityListener {

	@PrePersist
	public void prePersist(Volume target) {
		perform(target, Action.INSERTED);
	}

	@PreUpdate
	public void preUpdate(Volume target) {
		perform(target, Action.UPDATED);
	}

	@PreRemove
	public void preRemove(Volume target) {
		perform(target, Action.DELETED);
	}

	@Transactional(MANDATORY)
	private void perform(Volume target, Action action) {
		EntityManager entityManager = BeanUtil.getBean(EntityManager.class);

		entityManager.persist(new VolumeHistory(target, action));
	}

}