package me.ataur.bdlaws.admin.model;
import com.fasterxml.jackson.annotation.JsonView;
import lombok.Getter;
import lombok.Setter;
import me.ataur.bdlaws.admin.audit.Action;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

import static javax.persistence.EnumType.STRING;
import static javax.persistence.TemporalType.TIMESTAMP;

/**
 * @author Imran Hossain
 */

@Entity
@Table(name = "logtable")
@EntityListeners(AuditingEntityListener.class)
public class ActHistory {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "id")
	@Getter
	@Setter
	@JsonView(DataTablesOutput.View.class)
	private Integer id;

	@ManyToOne
	@JoinColumn(name="Act_id", referencedColumnName="id")
	@Getter
	@Setter
	@JsonView(DataTablesOutput.View.class)
	private Act file;

	@Column(name = "content")
	@Getter
	@Setter
	@JsonView(DataTablesOutput.View.class)
	private String fileContent;

	@CreatedBy
	@Column(name = "modifiedby")
	@Getter
	@Setter
	@JsonView(DataTablesOutput.View.class)
	private String modifiedBy;

	@CreatedDate
	@Temporal(TIMESTAMP)
	@Column(name = "modificationDate")
	@Getter
	@Setter
	@JsonView(DataTablesOutput.View.class)
	private Date modifiedDate;

	@Enumerated(STRING)
	@Column(name = "action")
	@Getter
	@Setter
	@JsonView(DataTablesOutput.View.class)
	private Action action;

	public ActHistory() {
	}

	public ActHistory(Act file, Action action) {
		this.file = file;
		this.fileContent = file.toString();
		this.action = action;
	}


}